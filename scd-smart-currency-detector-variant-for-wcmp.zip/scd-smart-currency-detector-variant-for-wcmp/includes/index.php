<?php
include 'scd-wcmp-rate-saver.php';
include 'scd-wcmp-functions.php';

include 'vendor/scd-wcmp-vendor-dashboard.php';
include 'vendor/scd-wcmp-vendor-dashboard-report.php';

include 'admin/scd-wcmp-report-by-admin-overview.php';
include 'admin/scd-wcmp-orders-report-vendor.php';